/* Akun saya (v26): ubah nama tampil, unduh data, keluar, hapus akun. v31: pilih bias. Butuh supabase/v26-moderasi.sql dan v31-komentar-reaksi-bias.sql. */
function paintHead(){ $("hbar").innerHTML = session ? `<span class="who">${myName()}</span>` : `<button class="btn green" data-act="login" type="button">Masuk</button>`; }
const say = (id, txt, err) => { const m = $(id); m.className = "msg" + (err ? " err" : ""); m.textContent = txt; };

async function loadName(){
  const meta = (session.user.user_metadata && (session.user.user_metadata.name || session.user.user_metadata.full_name)) || (session.user.email || "").split("@")[0];
  let nm = meta;
  try{ const p = await rest("profiles?id=eq." + encodeURIComponent(session.user.id) + "&select=display_name"); if(p && p[0] && p[0].display_name) nm = p[0].display_name; }catch(e){}
  $("nameIn").value = nm;
}
async function saveName(){
  const btn = $("nameForm").querySelector("button"); btn.disabled = true; say("nameMsg", "Menyimpan…");
  try{ await rpc("set_display_name", {p_name:$("nameIn").value}); say("nameMsg", "Tersimpan."); }
  catch(e){ say("nameMsg", e.message, true); }
  btn.disabled = false;
}
async function download(){
  const btn = $("dlBtn"); btn.disabled = true; say("dlMsg", "Menyiapkan…");
  try{
    const data = await rpc("export_my_data");
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type:"application/json"}));
    const a = document.createElement("a"); a.href = url; a.download = "bunnies-data-saya.json";
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    say("dlMsg", "Selesai. Berkas diunduh.");
  }catch(e){ say("dlMsg", e.message, true); }
  btn.disabled = false;
}
async function removeAccount(){
  if($("delIn").value.trim() !== "HAPUS") return;
  if(!confirm("Hapus akun dan semua kontenmu secara permanen?")) return;
  const btn = $("delBtn"); btn.disabled = true; say("delMsg", "Menghapus…");
  try{
    await rpc("delete_my_account");
    keep(null);
    $("akunView").hidden = true; paintHead();
    $("gateView").hidden = false;
    $("gateView").innerHTML = `<div class="gate"><p><b>Akunmu sudah dihapus.</b> Terima kasih sudah mencoba Bunnies Indonesia.</p><a class="btn green" href="./">Ke beranda</a></div>`;
  }catch(e){ say("delMsg", e.message, true); btn.disabled = $("delIn").value.trim() !== "HAPUS"; }
}

/* ---------- Bias (v31) ---------- */
let myBias = null;
function paintBias(){
  $("biasPick").innerHTML = [...BIAS.map(b => ({id:b.id, nama:b.nama, warna:b.warna})), {id:"none", nama:"Belum pilih", warna:"#5f6f8c"}]
    .map(b => `<button type="button" data-bias="${b.id}" style="--bc:${b.warna}" aria-pressed="${(myBias || "none") === b.id}">${esc(b.nama)}</button>`).join("");
}
async function loadBias(){
  try{
    const p = await rest("profiles?id=eq." + encodeURIComponent(session.user.id) + "&select=bias");
    myBias = p && p[0] && p[0].bias || null;
  }catch(e){ myBias = null; }
  paintBias();
}
async function saveBias(id){
  const val = id === "none" ? null : id;
  const btns = $("biasPick").querySelectorAll("button"); btns.forEach(b => b.disabled = true);
  say("biasMsg", "Menyimpan…");
  try{
    await rpc("set_bias", {p_bias:val}); myBias = val; paintBias(); say("biasMsg", "Tersimpan. Bias tampil di komentarmu berikutnya.");
  }catch(e){ say("biasMsg", e.message, true); }
  $("biasPick").querySelectorAll("button").forEach(b => b.disabled = false);
}

document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act],[data-bias],#dlBtn,#outBtn,#delBtn"); if(!t) return;
  if(t.dataset.bias) return saveBias(t.dataset.bias);
  if(t.dataset.act === "login") return googleLogin();
  if(t.id === "dlBtn") return download();
  if(t.id === "outBtn"){ await signOut(); location.href = "./"; return; }
  if(t.id === "delBtn") return removeAccount();
});
$("nameForm").addEventListener("submit", e => { e.preventDefault(); saveName(); });
$("delIn").addEventListener("input", () => { $("delBtn").disabled = $("delIn").value.trim() !== "HAPUS"; });
(async function(){
  if(!SUPABASE_URL || !SUPABASE_ANON_KEY){ $("gateView").innerHTML = `<p class="sinfo">Supabase belum dikonfigurasi di js/config.js.</p>`; return; }
  await initSession(); paintHead();
  if(!session){ $("gateView").innerHTML = gate("Masuk dulu untuk mengelola akunmu."); return; }
  $("gateView").hidden = true; $("akunView").hidden = false;
  $("who").textContent = session.user.email || "";
  loadName(); loadBias();
  rpc("is_admin").then(v => { $("adminBox").hidden = v !== true; }).catch(() => {});
})();
