# Bunnies Indonesia

Fanpage NewJeans tidak resmi untuk penggemar Indonesia. Tidak berafiliasi dengan ADOR atau NewJeans.

HTML, CSS, dan JavaScript murni di GitHub Pages, dengan Supabase untuk database, login, dan penyimpanan.

```
index.html, blog.html, tanya.html, akun.html, admin.html   halaman utama
css/    tokens (warna), base, identity, komentar, ...
js/    config (kunci Supabase), state, api, blog, tanya, akun, admin, bias, ...
supabase/   file SQL (jalankan urut sesuai HANDOFF.md bagian 4)
tools/  build-static.mjs (halaman statis untuk SEO)
```

- Dokumen lengkap, termasuk urutan SQL, aturan keamanan, dan rencana: baca **HANDOFF.md**.
- Navigasi (baris atas menempel, kotak cari ringkas, baris tab) ada di `css/navbar.css` dan `js/nav.js`. Baca HANDOFF.md bagian 5i.
- Ubah warna di `css/tokens.css`. Isi kunci Supabase di `js/config.js`.
- Urutan tag `<script>` harus dipertahankan. Naikkan `?v=NN` di semua HTML tiap rilis.
- Semua path relatif, jadi situs jalan di `username.github.io/bunniesindonesia`.

## Bahasa

Situs punya tiga bahasa: Indonesia (halaman di root), Inggris (`en/`), dan Korea (`ko/`). Tombol globe di baris atas (`js/lang.js`) membuka menu Indonesia / English / 한국어 dan membawa pengguna ke halaman yang sama di bahasa lain.
Data kabar Inggris dan Korea ada di `data/kabar.en.json` dan `data/kabar.ko.json` (selalu diperbarui bersama `data/kabar.json`).

## Menjalankan lokal / GitHub Codespaces

```bash
node tools/dev-server.mjs 8000      # lalu buka http://localhost:8000 (Codespaces: tab Ports, port 8000)
```

Memakai server ini, bukan `python -m http.server`, karena tautan tanpa `.html` (mis. `/galeri`) harus dikenali seperti di GitHub Pages.
Di Codespaces, server sudah berjalan otomatis lewat `.devcontainer/devcontainer.json`.
